const music = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴍᴜ́sɪᴄᴀ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴍᴜ́sɪᴄᴀ »

≽ *${prefix}musica* <musica>
*"Informações* ‹ Tocar música".* ›

*≽ *${prefix}joox* <musica>
*"Informações* ‹ Tocar música Joox".* ›

≽ *${prefix}letra* <musica>
*"Informações* ‹ Pesquisar Letras de Músicas".* ›
    
≽ *${prefix}chord* <musica>
*"Informações* ‹ Pesquisar letra da música de acordes."* ›
 
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ʟᴏɢᴏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
 `
}
exports.music = music
