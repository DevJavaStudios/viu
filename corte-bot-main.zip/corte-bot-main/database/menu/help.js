const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
♡‧₊˚ ❛Sabrinabot!.⌇🍂!

 « Informações do usuário »
 
≽ *Nome* : ${pushname}
≽ *XP* : ${reqXp}
≽ *CoinSabrina* : ${uangku}
≽ *Online : Sim️
  
   « Sabrina Info »
 *Prefixo* : 「  ${prefix}  」
┠≽ *Criador* : Dev Java Studios
┠≽ *Versão* : 0.0.5

 « *MENU* »
   ┠≽ *${prefix}logomenu*
   ┠≽ *${prefix}imagemenu*
   ┠≽ *${prefix}figmenu*
   ┠≽ *${prefix}buscamenu*
   ┠≽ *${prefix}educationmenu*
   ┠≽ *${prefix}porcentomenu*
   ┠≽ *${prefix}baixarmenu*
   ┠≽ *${prefix}mememenu*
   ┠≽ *${prefix}grupomenu*
   ┠≽ *${prefix}sommenu*
   ┠≽ *${prefix}musicmenu*
   ┠≽ *${prefix}stalkmenu*
   ┠≽ *${prefix}18+menu*
   ┠≽ *${prefix}funmenu*
   ┠≽ *${prefix}informationmenu*
   ┠≽ *${prefix}stayonscreenmenu*
   ┠≽ *${prefix}xpmenu*
   ┠≽ *${prefix}limitemenu*
   ┠≽ *${prefix}donomenu*
   ┠≽ *${prefix}outrosmenu*
   ╿SabrinaBOT 4.0 `
}
exports.help = help
