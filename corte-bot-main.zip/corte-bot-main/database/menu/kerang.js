const kerang = (prefix, botName, ownerName) => {
	return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴘᴏʀᴄᴇɴᴛᴀɢᴇᴍ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ɪɴғᴏʀᴍᴀᴄ̧ᴀ̃ᴏ »

≽ *${prefix}oque* 
*"Informações* ‹ Perguntar".* ›

*≽ *${prefix}vcpode* 
*"Informações* ‹ Você pode?".* ›

≽ *${prefix}quando* 
*"Informações* ‹ quando tal coisa?".* ›
    
≽ *${prefix}baianor*
*"Informações* ‹ Qual sua Porcentagem baianor?."* ›
    
≽ *${prefix}gay*
*"Informações* ‹ Qual sua Porcentagem gay?."* ›
    
≽ *${prefix}lindo* 
*"Informações* ‹ Qual sua Porcentagem lindo?"* ›
        
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴘᴏʀᴄᴇɴᴛᴀɢᴇᴍ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂`
}
exports.kerang = kerang
