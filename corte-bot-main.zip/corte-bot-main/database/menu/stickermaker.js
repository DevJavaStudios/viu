const stickermaker = (prefix, botName, ownerName) => {
	return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs ᴄʀɪᴀʀ ғɪɢ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴄʀɪᴀʀ ғɪɢ »

≽ *${prefix}fig* <usuário>
*"Informações* ‹ Criar Sticker Imagem".* ›

*≽ *${prefix}s* 
*"Informações* ‹ Criar fig animada/gif".* ›

*≽ *${prefix}ttp* 
*"Informações* ‹ Criar fig texto".* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴄʀɪᴀʀ ғɪɢ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
`
}
exports.stickermaker = stickermaker
