const information = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ɪɴғᴏʀᴍᴀᴄ̧ᴀ̃ᴏ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ɪɴғᴏʀᴍᴀᴄ̧ᴀ̃ᴏ »

≽ *${prefix}idiomas* 
*"Informações* ‹ Enviar todos códigos do idioma".* ›

*≽ *${prefix}paiscod* 
*"Informações* ‹ Enviar Código do país".* ›

≽ *${prefix}fato* 
*"Informações* ‹ Envie um fato aleatório ".* ›
    
≽ *${prefix}kbbi* <texto>
*"Informações* ‹ Perguntando ao KBBI."* ›
    
≽ *${prefix}clima* <texto>
*"Informações* ‹ Enviar informações meteorológicas."* ›
    
≽ *${prefix}covidpais* <país>
*"Informações* ‹ Enviar informações Covid 19."* ›
        
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴅɪᴠᴇʀsᴀ̃ᴏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂`
}
exports.information = information
