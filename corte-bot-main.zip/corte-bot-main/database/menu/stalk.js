const stalk = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs sᴛᴀʟᴋᴇᴀʀ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴘᴀʀᴀ ᴍᴇᴜ ᴅᴏɴᴏ »

≽ *${prefix}tiktokstalk* <usuário>
*"Informações* ‹ Obtenha informações do TikTok, usuário".* ›

*≽ *${prefix}igstalk* 
*"Informações* ‹ Obter informações do Instagram, usuário".* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs sᴛᴀʟᴋᴇᴀʀ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
`
}
exports.stalk = stalk
