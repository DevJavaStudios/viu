const downloader = (prefix, botName, ownerName) => {
	return `

   ♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ʙᴀɪxᴀʀ ᴠɪ́ᴅᴇᴏs/ɪᴍᴀɢᴇɴs/ᴛʜᴜᴍʙɴᴀɪʟs ᴅᴇ ᴀʟɢᴜᴍᴀs ʀᴇᴅᴇs sᴏᴄɪᴀɪs ᴠᴇᴊᴀ ᴀʙᴀɪxᴏ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʙᴀɪxᴀʀ »

≽ *${prefix}pin* 
*"Informações* ‹ com este recurso você faz pesquisas na plataforma Pinterest".* ›

*≽ *${prefix}baixarytbmp3* 
*"Informações* ‹ Use este comando para baixar vídeos do YouTube em mp3".* ›

*≽ *${prefix}baixarytbmp4* 
*"Informações* ‹ Use este comando para baixar vídeos do YouTube em mp4".* ›

*≽ *${prefix}tiktok* 
*"Informações* ‹ Use este comando para baixar vídeos do TikTok".* ›

♡‧₊˚ ᴜsᴇ ᴇsᴛᴇ ᴄᴏᴍᴀɴᴅᴏs ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.⌇🍂!
`
}
exports.downloader = downloader
