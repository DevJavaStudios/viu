const group = (prefix, botName, ownerName) => {
        return `
┏♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴘᴀʀᴀ ᴘʀᴏᴛᴇɢᴇʀ sᴇᴜ ɢʀᴜᴘᴏ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ɢʀᴜᴘᴏ sᴇɢᴜʀɪᴛʏ »

≽ *${prefix}abrirgp*
*"Informações* ‹ Abrir grupo para todos".* ›

*≽ *${prefix}fechargp* 
*"Informações* ‹ Trancar Grupo Para apenas admins".* ›

≽ *${prefix}adm* 
*"Informações* ‹ Enviar adm para um membro".* ›
    
≽ *${prefix}kickadm*
*"Informações* ‹ Retirar Admin De um Admin."* ›
    
≽ *${prefix}todos* <todos 1-5>
*"Informações* ‹ marcar todos do grupo [@] ."* ›

≽ *${prefix}add* <5511xxxxx>
*"Informações* ‹ Adicionar alguem ao Grupo ."* ›
    
≽ *${prefix}kick* <@membro>
*"Informações* ‹ Remover Alguem do grupo ."* ›
    
≽ *${prefix}alladmin*
*"Informações* ‹ Todos admins do grupo ."* ›

≽ *${prefix}linkgp*
*"Informações* ‹ Link do grupo ."* ›

≽ *${prefix}exit*
*"Informações* ‹ Sabrina Irá sair ."* ›

≽ *${prefix}bv* <sim> ou <nao>
*"Informações* ‹ dizer boas vindas quando alguem entrar,e tchau para quem sair ."* ›
    
≽ *${prefix}nsfw* <sim> ou <nao>
*"Informações* ‹ Ativar Nsfw Em seu Grupo ."* ›

≽ *${prefix}del*
*"Informações* ‹ Apagar mensagens do bot marcando elas ."* ›

≽ *${prefix}simih* <sim> <nao>
*"Informações* ‹ Ativar Modo Interação em seu grupo ."* ›

≽ *${prefix}tageu* 
*"Informações* ‹ Bot ira te marcar ."* ›
            
≽ *${prefix}showdono* 
*"Informações* ‹ Mostrar Criador Do Grupo ."* ›

≽ *${prefix}gpsegurity* 
*"Informações* ‹ Ativar antlink que você quer em seu grupo ."* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ɢʀᴜᴘᴏ sᴇɢᴜʀɪᴛʏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
 `
}
exports.group = group
