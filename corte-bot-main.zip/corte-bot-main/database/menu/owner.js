const owner = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs ᴘᴀʀᴀ ᴍᴇᴜ ᴅᴏɴᴏ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴘᴀʀᴀ ᴍᴇᴜ ᴅᴏɴᴏ »

≽ *${prefix}prefixset* <prefix>
*"Informações* ‹ Alterar prefix".* ›

*≽ *${prefix}block* 
*"Informações* ‹ Bloquear usuário".* ›

≽ *${prefix}unblock* 
*"Informações* ‹ Desbloquear usuário".* ›
    
≽ *${prefix}bc* <texto>
*"Informações* ‹ Enviar texto para TODOS."* ›
        
≽ *${prefix}clone* 
*"Informações* ‹ Clonar usuário."* ›    

≽ *${prefix}clearall*
*"Informações* ‹ Limpar chats."* ›
    
    
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴘᴀʀᴀ ᴍᴇᴜ ᴅᴏɴᴏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇
`
}
exports.owner = owner
