const other = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴏᴜᴛʀᴏs! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴏᴜᴛʀᴏs »

≽ *${prefix}send*
*"Informações* ‹ Indefinido".* ›

*≽ *${prefix}wame*
*"Informações* ‹ Seu link".* ›

≽ *${prefix}travazap* 
*"Informações* ‹ Enviar TravaZap".* ›
    
≽ *${prefix}qrcode* <texto>
*"Informações* ‹ Criar QrCode."* ›

 ≽ *${prefix}timer*
*"Informações* ‹ Indefinido."* ›

 ≽ *${prefix}fml*
*"Informações* ‹ Indefinido."* ›

 ≽ *${prefix}fml2*
*"Informações* ‹ Indefinido."* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴏᴜᴛʀᴏs ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
`
}
exports.other = other
