const education = (prefix, botName, ownerName) => {
	return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴇᴅᴜᴄᴀᴄ̧ᴀ̃ᴏ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴇᴅᴜᴄᴀᴄ̧ᴀ̃ᴏ »

≽ *${prefix}wikipedia* 
*"Informações* ‹ Buscas no site Wikipedia".* ›

*≽ *${prefix}wikien* 
*"Informações* ‹ Buscas no site Wikipédia (English)".* ›

≽ *${prefix}caderno* 
*"Informações* ‹ Escreva um texto no livro".* ›
    
≽ *${prefix}tradutor* <codigo linguagem|texto>
*"Informações* ‹ Tradução de textos."* ›
    
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ʙᴜsᴄᴀ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!`
}
exports.education = education
