const stayonscreen = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs UNDEFINED ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴘᴀʀᴀ UNDEFINED »

≽ *${prefix}afk* <razão>
*"Informações* ‹ Obtenha informações do TikTok, usuário".* ›
`
}
exports.stayonscreen = stayonscreen
