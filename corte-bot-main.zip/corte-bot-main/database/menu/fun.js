const fun = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴅɪᴠᴇʀsᴀ̃ᴏ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴅɪᴠᴇʀsᴀ̃ᴏ »

≽ *${prefix}alay* <texto>
*"Informações* ‹ Mudando Palavras em Alay".* ›

*≽ *${prefix}question* 
*"Informações* ‹ Perguntas para conhecer você".* ›

≽ *${prefix}simandnao* 
*"Informações* ‹ Jogo sim ou não".* ›
    
≽ *${prefix}simi* <texto>
*"Informações* ‹ Tradução de textos."* ›
    
≽ *${prefix}repete* <texto>
*"Informações* ‹ repetir tudo que você enviar."* ›
    
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴅɪᴠᴇʀsᴀ̃ᴏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
`
}
exports.fun = fun
