const logomaker = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ʟᴏɢᴏ! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ʟᴏɢᴏ »

≽ *${prefix}ninjalogo* <texto>
*"Informações* ‹ Faça uma imagem ninjalogo".* ›

*≽ *${prefix}logowolf* <texto>
*"Informações* ‹ Faça uma imagem logowolf".* ›

≽ *${prefix}phlogo* <texto>
*"Informações* ‹ Faça uma imagem phlogo".* ›
    
≽ *${prefix}neonlogo* <texto>
*"Informações* ‹ Faça uma imagem neonlogo."* ›
    
≽ *${prefix}neonlogo2* <texto>
*"Informações* ‹ Faça uma imagem neonlogo2."* ›

≽ *${prefix}lionlogo* <texto>
*"Informações* ‹ Faça uma imagem lionlogo"* ›    

≽ *${prefix}pubglogo* <texto>
*"Informações* ‹ Faça uma imagem pubglogo."* ›

≽ *${prefix}jokerlogo* <texto>
*"Informações* ‹ Faça uma imagem jokerlogo."* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ʟᴏɢᴏ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
 `
}
exports.logomaker = logomaker
