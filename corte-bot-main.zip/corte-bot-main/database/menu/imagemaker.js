const imagemaker = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʀᴇᴄᴜʀsᴏs ᴅᴇ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ɪᴍᴀɢᴇɴs! ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ɪᴍᴀɢᴇɴs »

≽ *${prefix}bpink* <texto>
*"Informações* ‹ Faça uma imagem BlackPink".* ›

*≽ *${prefix}snowwrite* <texto>
*"Informações* ‹ Faça uma imagem snowwrite".* ›

≽ *${prefix}3dtext* <texto>
*"Informações* ‹ Faça uma imagem 3dtexto".* ›
    
≽ *${prefix}firetext* <texto>
*"Informações* ‹ Faça uma imagem firetext."* ›
    
≽ *${prefix}glitch* <texto>
*"Informações* ‹ Faça uma imagem glitch."* ›

≽ *${prefix}shadow* <texto>
*"Informações* ‹ Faça uma imagem shadow"* ›    

≽ *${prefix}burnpaper* <texto>
*"Informações* ‹ Faça uma imagem burnpaper."* ›

≽ *${prefix}coffee* <texto>
*"Informações* ‹ Faça uma imagem coffe."* ›

≽ *${prefix}woodblock* <texto>
*"Informações* ‹ Faça uma imagem woodblock."* ›

≽ *${prefix}mutgrass* <texto>
*"Informações* ‹ Faça uma imagem mutgrass."* ›

≽ *${prefix}qowheart* <texto>
*"Informações* ‹ Faça uma imagem qowheart."* ›

≽ *${prefix}woodenboards* <texto>
*"Informações* ‹ Faça uma imagem woodenboards."* ›

≽ *${prefix}undergocean* <texto>
*"Informações* ‹ Faça uma imagem undergocean."* ›

≽ *${prefix}wolfmetal* <texto>
*"Informações* ‹ Faça uma imagem wolfmetal."* ›

≽ *${prefix}metalictglow* <texto>
*"Informações* ‹ Faça uma imagem metalictglow."* ›

≽ *${prefix}8bit* <texto>
*"Informações* ‹ Faça uma imagem 8bit."* ›

≽ *${prefix}herrypotter* <texto>
*"Informações* ‹ Faça uma imagem herrypotter."* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴄʀɪᴀᴅᴏʀ ᴅᴇ ɪᴍᴀɢᴇɴs ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂
`
}
exports.imagemaker = imagemaker
