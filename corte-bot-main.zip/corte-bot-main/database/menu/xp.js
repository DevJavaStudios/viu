const xp = (prefix, botName, ownerName) => {
        return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs ʟᴇᴠᴇʟ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ᴘᴀʀᴀ ʟᴇᴠᴇʟ»

≽ *${prefix}level* 
*"Informações* ‹ Check Meu level".* ›

*≽ *${prefix}leveling* 
*"Informações* ‹ Ativando/Desativando Recursos de Nivelamento".* ›

*≽ *${prefix}mining* 
*"Informações* ‹ Mining XP".* ›

≽ *${prefix}evento* 
*"Informações* ‹ Ativando/Desativando Recursos de Eventos".* ›

♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ʟᴇᴠᴇʟ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
`
}
exports.xp = xp
