const adult = (prefix, botName, ownerName) => {
        return `

♡‧₊˚ ❛ᴏɪɪ, ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ᴄᴏᴍᴀɴᴅᴏs 🔞
ᴛᴏᴅᴏs ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ᴀʙᴀɪxᴏs sᴀ̃ᴏ ᴇsᴘᴇᴄɪᴀʟ ᴘᴀʀᴀ ᴜsᴜᴀ́ʀɪᴏs 'sᴀsᴀ-ᴠɪᴘ.ᴜsᴇʀ' ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏs +𝟣𝟪 »

≽ *${prefix}hentai* 
*"Informações* ‹ Para usar este recurso,basta enviar o comando acima! 
não esqueça que este comando é vip".* ›

*≽ *${prefix}nsfwtrap* 
*"Informações* ‹ Para usar este recurso,basta enviar o comando acima! 
não esqueça que este comando é vip".* ›

≽ *${prefix}nsfwneko* 
*"Informações* ‹ Para usar este recurso,basta enviar o comando acima! 
não esqueça que este comando é vip".* ›
    
♡‧₊˚ ᴛᴏᴅᴏs ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs sᴀ̃ᴏ ɴᴇᴄᴇssᴀ́ʀɪᴏ ᴏ ɴsғᴡ ᴀᴛɪᴠᴏ.
 ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!
 `
}
exports.adult = adult
