const search = (prefix, botName, ownerName) => {
	return `
♡‧₊˚ ❛ᴏɪɪ,ᴇᴜ sᴀʙʀɪɴᴀ ᴛᴇɴʜᴏ ᴀʟɢᴜɴs ʙᴜsᴄᴀ sᴇᴀʀᴄʜ ᴛᴇɴʜᴀ ᴜᴍ ᴏ́ᴛɪᴍᴏ ᴅɪᴀ ᴜsᴀɴᴅᴏ sᴀʙʀɪɴᴀʙᴏᴛ!.⌇🍂!

   « ʟɪsᴛᴀ ʀᴇᴄᴜʀsᴏ ʙᴜsᴄᴀ sᴇᴀʀᴄʜ »

≽ *${prefix}qualanime* <prefix>
*"Informações* ‹ Qual é o anime?.* ›

*≽ *${prefix}ytsearch* 
*"Informações* ‹ Qual é o video?".* ›

≽ *${prefix}trendtwit* 
*"Informações* ‹ Qual é o trendtwit?".* ›
        
♡‧₊˚ ᴜsᴇ ᴇssᴇs ᴄᴏᴍᴀɴᴅᴏs ʙᴜsᴄᴀ sᴇᴀʀᴄʜ ᴄᴏᴍ ᴍᴏᴅᴇʀᴀᴄ̧ᴀ̃ᴏ.
`
}
exports.search = search
